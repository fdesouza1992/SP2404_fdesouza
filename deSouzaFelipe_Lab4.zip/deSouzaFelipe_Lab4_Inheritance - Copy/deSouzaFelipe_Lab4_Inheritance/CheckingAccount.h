#pragma once
#include "BaseAccount.h"


//Create this class that publicly derives from BaseAccount
class CheckingAccount :  public BaseAccount
{
public:
	//It has no additional data members and must override the Withdraw function
	void Withdraw(float amount) override;
protected:

private:

};

