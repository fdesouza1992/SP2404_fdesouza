#include "SavingsAccount.h"

//Must override the Withdraw function to enforce these rules:
void SavingsAccount::Withdraw(float amount)
{
	//Savings account will not allow more than 3 withdrawals
	if (numberOfWithdrawls >= 3)
	{
		//When this limit is hit there should be a message informing the user this happened.
		std::cout << "\nNo more withdrawls allowed for this account." << std::endl;
		std::cout << "\nCurrent Balance: $" << accountBalance << ".00\n" << std::endl;
		Helper::PrintLineSeparator();
	}
	else
	{
		accountBalance -= amount;
		std::cout << "\n$" << amount << ".00 were successfully withdrawn from your savings account!" << std::endl;
		std::cout << "\nCurrent Balance: $" << accountBalance << ".00\n" << std::endl;
		Helper::PrintLineSeparator();
	}
	numberOfWithdrawls++;
}
