#include "BaseAccount.h"

void BaseAccount::Withdraw(float amount)
{
	accountBalance -= amount;
	numberOfWithdrawls++;
}

void BaseAccount::Deposit(float amount)
{
	accountBalance += amount;
}

float BaseAccount::GetBalance() const
{
	return accountBalance;
}
