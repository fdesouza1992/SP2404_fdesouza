#pragma once
#include "BaseAccount.h"

//Create this class that publicly derives from BaseAccount.
class CreditAccount :  public BaseAccount
{
public:
	CreditAccount() : amountSpentSoFar(0) {}				//Base Constructor
	void Withdraw(float amount) override;					//Method
	
protected:

private:
	//Add a private int data member for the amount spent so far to be able to compare to the constant spending limit of 40.
	int amountSpentSoFar;
	const int spendingLimit = 40;
	const int feeAmount = 5000;

};

