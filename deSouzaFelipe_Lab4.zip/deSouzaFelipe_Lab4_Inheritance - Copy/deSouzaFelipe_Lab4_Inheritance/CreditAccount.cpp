#include "CreditAccount.h"

//Override the Withdraw function to enforce these rules:
void CreditAccount::Withdraw(float amount)
{
	//Credit accounts have a spending $40 limit and charge a $5000 fee if you go over that spending limit.
	float overLimit = amountSpentSoFar + amount;
	if (overLimit >= spendingLimit)
	{
		accountBalance -= (amount + feeAmount);
		//When this fee is applied there should be a message informing the user this happened.
		std::cout << "\nA $"<< feeAmount <<".00 fee has been applied to your account for exceeding the "<< spendingLimit << ".00 allowed spending limit!" << std::endl;
		std::cout << "\nCurrent Balance: $" << accountBalance << ".00" << std::endl;
		std::cout << "Recent Activities / Transactions: $" << overLimit << ".00\n" << std::endl;
		Helper::PrintLineSeparator();
	}
	else
	{
		accountBalance -= amount;
		amountSpentSoFar += amount;
		std::cout << "\n$" << amount << ".00 were successfully withdrawn from your credit account!" << std::endl;
		std::cout << "\nCurrent Balance: $" << accountBalance << ".00" << std::endl;
		std::cout << "Recent Activities / Transactions: $" << amountSpentSoFar << ".00\n" << std::endl;
		Helper::PrintLineSeparator();
	}
}


