// deSouzaFelipe_Lab2.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Draft Version 4/11/2024

#include <iostream>
#include "deSouzaFelipe_Lab2.h"

void repaintCar(Car* ptrCar, EnumColorDefinition newcolor) {
	ptrCar->Color = newcolor;
}

//Program 1
void Program1() {					
	int array[15]{};											//Declares an array of 15 ints.
	for (int i = 0; i < 15; i++) {								//Loops through array to assign a random number to each slot
	
		array[i] = rand() % 100;
	}
	for (int i = 0; i < 15; i++) {								//Loopa through the array to print out the Value and Memory Address of each item in the array
		std::cout << "Value: " << array[i] << "\t" << "Memory Address: " << &array[i] << std::endl;
	}
}

void printIntAndPointer(int number, int* pointer) {				//Function that prints out the int and the int pointer parameters without using any operators on the pointer
	std::cout << "Value: " << number << "\t" << "Memory Address: " << pointer << std::endl;
}

//Program 2
void Program2 (){							
	int array2[15]{};											//Declares an array of 15 ints.
	for (int i = 0; i < 15; i++) {								//Loops through array to assign a random number to each slot
		array2[i] = rand() % 100;
	}
	for (int i = 0; i < 15; i++) {								
		printIntAndPointer(array2[i], &array2[i]);				//Loops through array to recursively  call the printIntAndPointer method.
	}
}

Car carArray[3]{};
//Program 3
void Program3() {
	for (int i = 0; i < 3; i++) {
		std::cout << "Enter Make for Car " << i + 1 << ": ";
		std::cin.getline(carArray[i].Make, 32);
		std::cin.ignore(INT_MAX, '\n');

		std::cout << "Enter Model for Car " << i + 1 << ": ";
		std::cin.getline(carArray[i].Model, 32);
		std::cin.ignore(INT_MAX, '\n');

		std::cout << "Enter Year for Car " << i + 1 << ": ";
		std::cin >> carArray[i].Year;
		if (std::cin.fail()) {									//Unexpected input put in
			std::cin.clear();									//Clears any erros in cin
			std::cin.ignore(INT_MAX, '\n');						//flushes INT_MAX chars in buffer until you see '\n'
		}

		std::cout << "Enter Mileage for Car " << i + 1 << ": ";
		std::cin >> carArray[i].Mileage;
		if (std::cin.fail()) {									//Unexpected input put in
			std::cin.clear();									//Clears any erros in cin
			std::cin.ignore(INT_MAX, '\n');						//Flushes INT_MAX chars in buffer until you see '\n'
		}

		int colorInput;
		std::cout << "Enter color (Black=0, Red=1, Blue=2, Green=3, Yellow=4) for Car " << i + 1 << ": ";
		std::cin >> colorInput;
		carArray[i].Color = static_cast<EnumColorDefinition>(colorInput);
		if (std::cin.fail()) {									//Unexpected input put in
			std::cin.clear();									//Clears any erros in cin
			std::cin.ignore(INT_MAX, '\n');						//flushes INT_MAX chars in buffer until you see '\n'
		}
	}
	std::cout << "\n*************************************************" << std::endl;

	std::cout << "\nPrinting Cars ..." << std::endl;
	for (int i = 0; i < 3; i++) {	
		std::cout << "Car " << i + 1 << " - "; 
		printCar(carArray[i]);
	}

	std::cout << "\nPrinting Car Pointers ..." << std::endl;
	for (int i = 0; i < 3; i++) {
		std::cout << "Car " << i + 1 << " - ";
		printCarPointer(&carArray[i]);
	}
	std::cout << "\n*************************************************" << std::endl;

}

void printCar(Car c)
{
	int i = 0;
	std::cout << c.Year << " "; 
	switch (c.Color)
	{
	case Red:
		std::cout << "Red";
		break;
	case Blue:
		std::cout << "Blue";
		break;
	case Green:
		std::cout << "Green";
		break;
	case Yellow:
		std::cout << "Yellow";
		break;
	case Black:
		std::cout << "Black";
		break;
	default:
		std::cout << "Unknown Color";
		break;
	}
	std::cout << " " << c.Make << " " << c.Model << " with " 
		<< c.Mileage << " miles." << std::endl;
}

void printCarPointer(Car* ptrCar)
{
	int i = 0;
	std::cout << ptrCar->Year << " ";
	switch (ptrCar->Color)
	{
	case Red:
		std::cout << "Red";
		break;
	case Blue:
		std::cout << "Blue";
		break;
	case Green:
		std::cout << "Green";
		break;
	case Yellow:
		std::cout << "Yellow";
		break;
	case Black:
		std::cout << "Black";
		break;
	default:
		std::cout << "Unknown Color";
		break;
	}
	std::cout << " " << ptrCar->Make << " " << ptrCar->Model 
		<< " with " << ptrCar->Mileage << " miles." << std::endl;
}

void addMileage(Car* ptrCar, int milestoadd)
{
	ptrCar->Mileage += milestoadd;
}


int main() {

	std::cout << "******************* PROGRAM 1 *******************" << "\n" << std::endl;
	Program1();
	std::cout << "\n******************* PROGRAM 2 *******************" << "\n" << std::endl;
	Program2();
	std::cout << "\n******************* PROGRAM 3 *******************" << "\n" << std::endl;
	Program3();
	
	int userInput;
	do {
		std::cout << "\n1. Add Mileage" << std::endl;
		std::cout << "2. Repaint Car" << std::endl;
		std::cout << "3. Exit" << std::endl;
		std::cout << "\nChoose one of the options above: ";
		std::cin >> userInput;
		if (std::cin.fail()) {									//Unexpected input put in
			std::cin.clear();									//Clears any erros in cin
			std::cin.ignore(INT_MAX, '\n');						//flushes INT_MAX chars in buffer until you see '\n'
		}

		switch (userInput)
		{
		case 1:
			int carIndex;
			int mileageToAdd;
			std::cout << "Enter car index (1-3): ";
			std::cin >> carIndex;
			if (std::cin.fail()) {									//Unexpected input put in
				std::cin.clear();									//Clears any erros in cin
				std::cin.ignore(INT_MAX, '\n');						//flushes INT_MAX chars in buffer until you see '\n'
			}
			std::cout << "Enter mileage to add: ";
			std::cin >> mileageToAdd;
			if (std::cin.fail()) {									//Unexpected input put in
				std::cin.clear();									//Clears any erros in cin
				std::cin.ignore(INT_MAX, '\n');						//flushes INT_MAX chars in buffer until you see '\n'
			}
			addMileage(&carArray[carIndex - 1], mileageToAdd);
			std::cout << "\n*************************************************" << std::endl;
			std::cout << "\nPrinting Cars ..." << std::endl;
			for (int i = 0; i < 3; i++) {
				std::cout << "Car " << i + 1 << " - ";
				printCar(carArray[i]);
			}

			std::cout << "\nPrinting Car Pointers ..." << std::endl;
			for (int i = 0; i < 3; i++) {
				std::cout << "Car " << i + 1 << " - ";
				printCarPointer(&carArray[i]);
			}
			std::cout << "\n*************************************************" << std::endl;
			break;
		case 2:
			int colorUpdate;
			std::cout << "Enter car index (1-3): ";
			std::cin >> carIndex;
			if (std::cin.fail()) {									//Unexpected input put in
				std::cin.clear();									//Clears any erros in cin
				std::cin.ignore(INT_MAX, '\n');						//flushes INT_MAX chars in buffer until you see '\n'
			}
			std::cout << "Enter new color (0-4): ";
			std::cin >> colorUpdate;
			if (std::cin.fail()) {									//Unexpected input put in
				std::cin.clear();									//Clears any erros in cin
				std::cin.ignore(INT_MAX, '\n');						//flushes INT_MAX chars in buffer until you see '\n'
			}
			repaintCar(&carArray[carIndex - 1], static_cast<EnumColorDefinition>(colorUpdate));
			std::cout << "\n*************************************************" << std::endl;
			std::cout << "\nPrinting Cars ..." << std::endl;
			for (int i = 0; i < 3; i++) {
				std::cout << "Car " << i + 1 << " - ";
				printCar(carArray[i]);
			}

			std::cout << "\nPrinting Car Pointers ..." << std::endl;
			for (int i = 0; i < 3; i++) {
				std::cout << "Car " << i + 1 << " - ";
				printCarPointer(&carArray[i]);
			}
			std::cout << "\n*************************************************" << std::endl;
			break;
		case 3:
			std::cout << "Exiting program....." << std::endl;
			break;
		default:
			std::cerr << "Invalid choice. Please try again!" << std::endl;
			break;
		}
	} while (userInput != 3);
	
	std::cout << "\n*************************************************\n" << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
