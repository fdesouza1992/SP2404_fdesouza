#pragma once

//Declares an enum with at least 2 values
enum EnumColorDefinition { Black, Red, Blue, Green, Yellow, Orange, Cyan, Pink, Teal };

//Create struct Car with members Make, Model, Year, Mileage, and Color
struct Car
{
	char Make[32];
	char Model[32];
	int Year;
	int Mileage;
	EnumColorDefinition Color;
};

void repaintCar(Car* ptrCar, EnumColorDefinition newcolor);
void Program1();
void printIntAndPointer(int number, int* pointer);
void Program2();
void Program3();

void printCar(Car c);
void printCarPointer(Car* ptrCar);
void addMileage(Car* ptrCar, int milestoadd);
