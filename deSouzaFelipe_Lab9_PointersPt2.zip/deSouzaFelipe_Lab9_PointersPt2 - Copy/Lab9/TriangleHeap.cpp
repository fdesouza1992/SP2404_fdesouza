#pragma once
#include "TriangleHeap.h"

TriangleHeap::TriangleHeap()
{
	mBase = new float;
	mHeight = new float;
}

TriangleHeap::TriangleHeap(const TriangleHeap& other)
{
	mBase = new float;
	*mBase = *(other.mBase);
	mHeight = new float;
	*mHeight = *(other.mHeight);
}

TriangleHeap& TriangleHeap::operator=(const TriangleHeap& other)
{
	if (this != &other) {
		*mBase = *other.mBase;
		*mHeight = *other.mHeight;
	}
	return *this;
}

TriangleHeap::~TriangleHeap()
{
	delete mBase;
	delete mHeight;
}

void TriangleHeap::SetBase(float base)
{
	*mBase = base;
}

void TriangleHeap::SetHeight(float height)
{
	*mHeight = height;
}

float TriangleHeap::GetArea() const
{
	return (*mBase * *mHeight) / 2.0f;
}
