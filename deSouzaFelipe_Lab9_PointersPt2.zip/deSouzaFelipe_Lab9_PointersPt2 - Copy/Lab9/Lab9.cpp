// Lab9.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#pragma once
#include "Header.h"
#include "TriangleStack.h"
#include "TriangleHeap.h"
#include <vector>
#include <crtdbg.h>         //For memory leak detection

// Change this number to the line number the Output window shows you
// to follow a memory leak. Put -1 to disable.
#define MEMORY_LEAK_LINE -1

//Function to set the base and height for a trianglestack by using User Input
void SetBaseAndHeightForTriangle(TriangleStack& triangle)
{
    float base;
    float height;
    std::cout << "Enter Base: \t\t";
    std::cin >> base;
    std::cout << "Enter Height: \t\t";
    std::cin >> height;
    triangle.SetBase(base);
    triangle.SetHeight(height);
}

//Function to set random base and height for a trianglestack (computer generated)
void SetRandomBaseAndHeightForTriangle(TriangleStack& triangle)
{
    float base = GetRandomFloat(0.0, 20.0);
    float height = GetRandomFloat(0.0, 20.0);
    std::cout << "Computer Generated Base: \t" << base << std::endl;
    std::cout << "Computer Generated Height: \t" << height << std::endl;
    triangle.SetBase(base);
    triangle.SetHeight(height);
}

//Function to set the base and height for a triangleheap by using User Input
void SetBaseAndHeightForTriangleHeap(TriangleHeap& triangle)
{
    float base;
    float height;
    std::cout << "Enter Base: \t\t";
    std::cin >> base;
    std::cout << "Enter Height: \t\t";
    std::cin >> height;
    triangle.SetBase(base);
    triangle.SetHeight(height);
}

//Function to set random base and height for a triangleheap (computer generated)
void SetRandomBaseAndHeightForTriangleHeap(TriangleHeap& triangle)
{
    float base = GetRandomFloat(0.0, 20.0);
    float height = GetRandomFloat(0.0, 20.0);
    std::cout << "Computer Generated Base: \t" << base << std::endl;
    std::cout << "Computer Generated Height: \t" << height << std::endl;
    triangle.SetBase(base);
    triangle.SetHeight(height);
}

//The first function should return the sum of the datas pointed at by the two int pointers.
int AddNumbersReturnInt(int* a, int* b)
{
    int sum = *a + *b;      //Dereference the pointers to get the actual values pointed at by a and b
    return sum;
}

//The second function should not return anything but instead store the result of the sum of a and b into the data of the sum pointer.
void AddNumbersReturnVoid(int a, int b, int* sum)
{
    *sum = a + b;           //Calculate the sum of a and b
}

//This function should swap the data pointed at by both pointers. 
//Example: a�s data is 5 and b�s data is 10: the function will make a�s data 10 and b�s data 5.
void SwapValues(int* a, int* b)
{
    int temp = *a;          //Temporary variable to store the data at a
    *a = *b;                //Swap the data at a with the data at b
    *b = temp;              //Set the data at b to the temporary variable
}

int main()
{
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
    _CrtSetBreakAlloc(MEMORY_LEAK_LINE);

    srand(static_cast<unsigned>(time(nullptr)));        //Seed the random number generator

    const char* triangleOption[3] = { "TriangleStack", "TriangleHeap", "Exit" };
    const char* menuOption[3] = { "User Input Values", "Computer Generated Values (Random between 0 - 20.0)", "Exit" };
    const char* yesOrNo[2] = {"Yes", "No"};

    std::cout << "Which Triangle To Create: \n" << std::endl;
    int triangleSelection = PrintMenuAndGetSelection(triangleOption, 3);
    int userSelection;
    
    //Declare two TriangleStack variables and set their members to whatever two different values you want.
    TriangleStack stackTriangle1;
    TriangleStack stackTriangle2;
    TriangleHeap heapTriangle1;
    TriangleHeap heapTriangle2;

    std::vector<TriangleStack> stackTriangles;              //Vector of TriangleStack objects
    std::vector<TriangleHeap> heapTriangles;                //Vector of TriangleHeap objects
    
    stackTriangles.push_back(stackTriangle1);
    stackTriangles.push_back(stackTriangle2);
    heapTriangles.push_back(heapTriangle1);
    heapTriangles.push_back(heapTriangle2);

    bool running = true;
    while (running)
    {
        if (triangleSelection == 1)
        {
            PrintLineSeparator();
            std::cout << "Select How To Generate Values For Each TriangleStack:\n" << std::endl;
            userSelection = PrintMenuAndGetSelection(menuOption, 3);

            if (userSelection == 1)
            {
                ClearConsole();
                std::cout << "Setting Values For Triangle 1: \t" << std::endl;
                SetBaseAndHeightForTriangle(stackTriangles[0]);
                std::cout << std::endl;
                std::cout << "Setting Values For Triangle 2: \t" << std::endl;
                SetBaseAndHeightForTriangle(stackTriangles[1]);
                std::cout << std::endl;
                
                // Print the areas for TriangleStack objects
                std::cout << "TriangleStack Area Results:" << std::endl;
                for (int i = 0; i < stackTriangles.size(); ++i)
                {
                   std::cout << "Triangle " << i + 1 << " area: \t" << stackTriangles[i].GetArea() << std::endl;
                }
            }
            else if (userSelection == 2)
            {
                std::cout << "Setting Values For Triangle 1: \t" << std::endl;
                SetRandomBaseAndHeightForTriangle(stackTriangles[0]);
                std::cout << std::endl;
                std::cout << "Setting Random Values For Triangle 2:" << std::endl;
                SetRandomBaseAndHeightForTriangle(stackTriangles[1]);
                std::cout << std::endl;
               
                // Print the areas for TriangleStack objects
                std::cout << "TriangleStack Area Results:" << std::endl;
                for (int i = 0; i < stackTriangles.size(); i++)
                {
                    std::cout << "Triangle " << i + 1 << " area: \t" << stackTriangles[i].GetArea() << std::endl;
                }
            }
            else if (userSelection == 3)
            {
                ClearConsole();
                running = false;
                std::cout << "Thank you for using the program" << std::endl;
            }
            else
            {
                ClearConsole();
                std::cerr << "Invalid Input! Please Try Again To Continue ..." << std::endl;
            }
        }
        else if (triangleSelection == 2)
        {
            PrintLineSeparator();
            std::cout << "Select How To Generate Values For Each TriangleHeap:\n" << std::endl;
            userSelection = PrintMenuAndGetSelection(menuOption, 3);

            if (userSelection == 1)
            {
                ClearConsole();
                std::cout << "Setting Values For Triangle 1: \t" << std::endl;
                SetBaseAndHeightForTriangleHeap(heapTriangles[0]);
                std::cout << std::endl;
                std::cout << "Setting Values For Triangle 2: \t" << std::endl;
                SetBaseAndHeightForTriangleHeap(heapTriangles[1]);
                std::cout << std::endl;
               
                // Print the areas for TriangleStack objects
                std::cout << "TriangleHeap Area Results:" << std::endl;
                for (int i = 0; i < heapTriangles.size(); i++)
                {
                    std::cout << "Triangle " << i + 1 << " area: \t" << heapTriangles[i].GetArea() << std::endl;
                }
            }
            else if (userSelection == 2)
            {
                ClearConsole();
                std::cout << "Setting Random Values For Triangle 1:" << std::endl;
                SetRandomBaseAndHeightForTriangleHeap(heapTriangles[0]);
                std::cout << std::endl;
                std::cout << "Setting Random Values For Triangle 2:" << std::endl;
                SetRandomBaseAndHeightForTriangleHeap(heapTriangles[1]);
                std::cout << std::endl;
                
                // Print the areas for TriangleStack objects
                std::cout << "TriangleHeap Area Results:" << std::endl;
                for (int i = 0; i < heapTriangles.size(); i++)
                {
                    std::cout << "Triangle " << i + 1 << " area: \t" << heapTriangles[i].GetArea() << std::endl;
                }
            }
            else if (userSelection == 3)
            {
                ClearConsole();
                running = false;
                std::cout << "Thank you for using the program" << std::endl;
            }
            else 
            {
                ClearConsole();
                std::cerr << "Invalid Input! Please Try Again To Continue ..." << std::endl;
            } 
        }
        else
        {
            ClearConsole();
            running = false;
            std::cout << "Thank you for using the program" << std::endl;
        }
    }
}
