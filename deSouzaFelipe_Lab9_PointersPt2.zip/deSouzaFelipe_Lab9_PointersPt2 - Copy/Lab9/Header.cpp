#include "Header.h"

int GetValidatedInt(const char* strMessage, int nMinimumRange, int nMaximumRange)
{
    char userInput[10];
    int nUserInput;

    bool validation = true;

    do
    {
        std::cout << strMessage << std::endl;
        std::cin >> nUserInput;
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cerr << "Invalid entry! Please try again to continue ... " << std::endl;
        }
        else {
            //The range check should be ignored if BOTH the minimum and maximum parameters are 0, so any valid integer is acceptable.
            if ((nUserInput >= nMinimumRange || nMinimumRange == 0) && (nUserInput <= nMaximumRange || nMaximumRange == 0)) {
                return nUserInput;
            }
            else {
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                std::cerr << "Invalid entry! Please try again to continue ... " << std::endl;
            }
        }
    } while (validation);
}

int GetRandomIntNumber(int nMinimum, int nMaximum)
{
    srand(static_cast<unsigned int>(time(0)));
    return rand() % (nMaximum - nMinimum + 1) + nMinimum;
}

void ClearCinBuffer()
{
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

int PrintMenuAndGetSelection(const char* menuOptions[], int numberOptions)
{
    for (int i = 0; i < numberOptions; i++)
    {
        std::cout << i + 1 << ". " << menuOptions[i] << std::endl;
    }
    return GetValidatedInt("\nSelect an Option: ", 1, numberOptions);
}

void PrintBits(unsigned int bitField)
{
    for (int i = 31; i >= 0; i--) {     //Loops through each bit from the mosto the least significant bit (0)
        if (bitField & (1 << i)) {      //If the bit is set, print '1'
            std::cout << "1";
        }
        else {                          //if the bit is not set, print '0'
            std::cout << "0";
        }
        if (i % 4 == 0) {               //Adds a space every 4 bits for better readability
            std::cout << " ";
        }
    }
}

void PrintLineSeparator()
{
    std::cout << "\n*************************************************************\n" << std::endl;
}

void PrintIntegerInFormats(int numToBeConverted)
{
    std::cout << "Decimal: \t" << numToBeConverted << std::endl;
    unsigned int bits = static_cast<unsigned int> (numToBeConverted);
    std::cout << "Binary: \t";
    PrintBits(bits);
    std::cout << std::endl;
    char hex_string[20];
    sprintf_s(hex_string, "%X", numToBeConverted);
    std::cout << "Hexadecimal: \t" << hex_string << std::endl;
    std::cout << "Octal: \t\t0" << std::oct << numToBeConverted << std::endl;
}

void PrintPressEnterKey()
{
    std::cout << "Press the Enter Key to continue ..." << std::endl;
    std::cin.get();                     // Pause the console before moving on.
}

void ClearConsole()
{
    std::cout << "\x1B[2J\x1b[H";
}

void PrintBannerMessage(char message[])
{
    ClearConsole();
    PrintLineSeparator();
    std::cout << " " << message << "\n" << std::endl;
    PrintLineSeparator();
}

float GetRandomFloat(float min, float max)
{
    {
        float randomFloat = min + static_cast<float>(rand()) / (static_cast<float> (RAND_MAX / (max - min)));
        return randomFloat;
    }
}















