#pragma once
#include <iostream>
#include <climits>
#include <cstdlib>          //For random number generation
#include <ctime>            //For seeding random number generator

/// <summary>
  /// This function should first display the provided message to the screen then use cin to get an int from the user.
  ///  Error check and validate to ensure a legal integer was entered. 
  ///  If not, clear the cin buffer using clear() and ignore() and try again 
  ///  (Note: the buffer still needs to be cleared even if this step was successful).
  /// </summary>
  /// <param name="strMessage">The provided message to be output for the user</param>
  /// <param name="nMinimumRange">Minimum Number for the Range</param>
  /// <param name="nMaximumRange">Maximum Number for the Range</param>
  /// <returns>If the user input was within the range, return the integer. 
  /// If not, get input again.</returns>
int GetValidatedInt(const char* strMessage, int nMinimumRange = 0, int nMaximumRange = 0);

/// <summary>
    /// Helper Function to return a Random Number within a range.
    /// </summary>
    /// <param name="nMinimum">Minimum Number for the Range</param>
    /// <param name="nMaximum">Maximum Number for the Range</param>
    /// <returns>Random Int Number</returns>
int GetRandomIntNumber(int nMinimum, int nMaximum);

/// <summary>
  /// Helper Function to clear and ignore the cin input buffer
  /// </summary>
void ClearCinBuffer();

/// <summary>
    /// Helper Function that prints a menu (array of strings) and return the user�s selection
    /// </summary>
    /// <param name="menuOptions">Different Options that will be displayed</param>
    /// <param name="numberOptions">Number of options available</param>
    /// <returns></returns>
int PrintMenuAndGetSelection(const char* menuOptions[], int numberOptions);

/// <summary>
    /// Helper Function to print the binary representation of an unsigned integer.
    /// </summary>
    /// <param name="bitField">Binary Bits Representation</param>
void PrintBits(unsigned int bitField);

/// <summary>
    /// Helper function that prints out a line of *** to be used as separator
    /// </summary>
void PrintLineSeparator();

/// <summary>
  /// Helper Function that prints a provided integer in binary, hex, or oct
  /// </summary>
  /// <param name="numToBeConverted">Int to be converted</param>
void PrintIntegerInFormats(int numToBeConverted);

/// <summary>
    /// Helper Function that displays "Press the Enter Key to continue" and wait for the enter to continue.
    /// </summary>
void PrintPressEnterKey();

/// <summary>
    /// Helper Function that uses ANSI/VT100 Escape Sequence to Clear console and returns the cursor
    /// to the first position.
    /// "\x1B[2J\x1b[H" stands for:
    /// \003 - ASCII escape character
    /// [H - move the cursor to the home position
    /// {J - erases the screen from the current line down to the bottom line of the screen
    /// </summary>
void ClearConsole();

/// <summary>
    /// Helper Function that shows a given message inside a banner box component
    /// </summary>
    /// <param name="message"></param>
void PrintBannerMessage(char message[]);

//Function to generate random float between min and max 
float GetRandomFloat(float min, float max);
