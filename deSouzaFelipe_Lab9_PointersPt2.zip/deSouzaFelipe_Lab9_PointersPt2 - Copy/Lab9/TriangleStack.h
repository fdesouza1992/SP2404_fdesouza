#pragma once

//Create two separate triangle classes: one where the members are stored on the stack (float)
class TriangleStack
{
	//Each triangle should have: private mBase and mHeight members
private:
	//field members
	float mBase;
	float mHeight;

	//two public Set methods to allow main to change each of these members� values.
	//public method GetArea() that returns the area
public:
	//Setters
	void SetBase(float base);
	void SetHeight(float height);

	//Getters
	float GetArea() const;
};


