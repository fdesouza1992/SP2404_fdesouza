#pragma once

//Create two separate triangle classes: one where the members are stored on the heap (dynamic float*).
class TriangleHeap
{
	//Each triangle should have: private mBase and mHeight members
private:
	//field members
	float* mBase;
	float* mHeight;

	//two public Set methods to allow main to change each of these members� values.
	//public method GetArea() that returns the area
	//he dynamic Triangle must fully implement the rule of 3. 
public:
	//Rule of 3:
	TriangleHeap();
	TriangleHeap(const TriangleHeap& other);
	TriangleHeap& operator=(const TriangleHeap& other);
	~TriangleHeap();

	//two public Set methods to allow main to change each of these members� values.
	//These should NOT receive float* for the heap class, just float parameters for the data to set your datas to.
public:
	//Setters
	void SetBase(float base);
	void SetHeight(float height);

	//public method GetArea() that returns the area. Does NOT return a float* for the heap class, still just a float data result.
	//Getters
	float GetArea() const;
};
