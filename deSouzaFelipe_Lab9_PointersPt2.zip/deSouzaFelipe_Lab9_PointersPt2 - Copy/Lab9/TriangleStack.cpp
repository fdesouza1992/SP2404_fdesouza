#include "TriangleStack.h"

//Setters
void TriangleStack::SetBase(float base)
{
	mBase = base;
}

void TriangleStack::SetHeight(float height)
{
	mHeight = height;
}

//Getters
float TriangleStack::GetArea() const
{
	return (mBase * mHeight) / 2.0f;
	
}
