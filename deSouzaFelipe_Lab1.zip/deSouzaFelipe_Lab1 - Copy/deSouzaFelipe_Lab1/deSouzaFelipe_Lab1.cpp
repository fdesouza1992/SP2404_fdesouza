// deSouzaFelipe_Lab1.cpp 
// Draft Version 4/9/2024
#include <iostream>

unsigned int bitField = 0;                  // Global variable to hold the bitField value
static void TurnOn(int bit) {           //Function to turn on a specific bit in the bitField
    bitField |= 1 << bit;
}

static void TurnOff(int bit) {          //Function to turn off a specific bit in the bitField
    bitField &= ~(1 << bit);
}

static void Toggle(int bit) {           //Function to toggle a specific bit in the bitField
    bitField ^= 1 << bit;
}

static void Negate() {                  //Function to negate all the bits in the bitField
    bitField = ~bitField;
}

static void LeftShift() {               //Function to the left shift the bitField by 1
    bitField <<= 1;
}

static void RightShift() {              //Function to the right shift the bitField by 1
    bitField >>= 1;
}

static void PrintBits(unsigned int) {   //Function to print the binary representation of an unsigned integer.
    for (int i = 31; i >= 0; i--) {     //Loops through each bit from the mosto the least significant bit (0)
        if (bitField & (1 << i)) {      //If the bit is set, print '1'
            std::cout << "1";
        }
        else {                          //if the bit is not set, print '0'
            std::cout << "0";
        }
        if (i % 4 == 0) {               //Adds a space every 4 bits for better readability
            std::cout << " ";
        }
    }
}

int main()
{
    int operation;
    do {
        std::cout << "bitField: " << bitField << std::endl;
        std::cout << "Bits: ";
        PrintBits(bitField);
        std::cout << std::endl;

        //Displays a menu of options for the user to chose from
        std::cout << "\nWhat would you like to do?" << std::endl;
        std::cout << "\nTurnOn = 1, TurnOff = 2, Toggle = 3, Negate = 4, Left Shift = 5, Right Shift = 6, Exit = 7" << std::endl;
        std::cout << "\nChoose operation: ";
        std::cin >> operation;
        if (std::cin.fail()) {									//Unexpected input put in
            std::cin.clear();									//Clears any erros in cin
            std::cin.ignore(INT_MAX, '\n');						//Flushes INT_MAX chars in buffer until you see '\n'
        }
        std::cout << std::endl;

        int bit;

        if (operation >= 1 && operation <= 3) {
            std::cout << "Choose Bit Index: ";
            std::cin >> bit;
            if (std::cin.fail()) {									//Unexpected input put in
                std::cin.clear();									//Clears any erros in cin
                std::cin.ignore(INT_MAX, '\n');						//Flushes INT_MAX chars in buffer until you see '\n'
            }
            std::cout << std::endl;
        }

        switch (operation)
        {
        case 1:
            TurnOn(bit);
            std::cout << "Updated bitField: " << bitField << std::endl;
            std::cout << "Bits: ";
            PrintBits(bitField);
            std::cout << "\n---------------------------------\n";
            std::cout << std::endl;
            break;
        case 2:
            TurnOff(bit);
            std::cout << "Updated bitField: " << bitField << std::endl;
            std::cout << "Bits: ";
            PrintBits(bitField);
            std::cout << "\n---------------------------------\n";
            std::cout << std::endl;
            break;
        case 3:
            Toggle(bit);
            std::cout << "Updated bitField: " << bitField << std::endl;
            std::cout << "Bits: ";
            PrintBits(bitField);
            std::cout << "\n---------------------------------\n";
            std::cout << std::endl;
            break;
        case 4:
            Negate();
            std::cout << "Updated bitField: " << bitField << std::endl;
            std::cout << "Bits: ";
            PrintBits(bitField);
            std::cout << "\n---------------------------------\n";
            std::cout << std::endl;
            break;
        case 5:
            LeftShift();
            std::cout << "Updated bitField: " << bitField << std::endl;
            std::cout << "Bits: ";
            PrintBits(bitField);
            std::cout << "\n---------------------------------\n";
            std::cout << std::endl;
            break;
        case 6:
            RightShift();
            std::cout << "Updated bitField: " << bitField << std::endl;
            std::cout << "Bits: ";
            PrintBits(bitField);
            std::cout << "\n---------------------------------\n";
            std::cout << std::endl;
            break;
        case 7:
           std::cout<< "Exiting the program...." << std::endl;
           break;
        default:
            std::cerr << "Invalid operation choice" << std::endl;
            break;
        }
        // Clear previous inputs for memory enhancement
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    } while (operation != 7);
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
