// deSouzaFelipe_Lab7_DoublyLinkedLists.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "DList.h"
#include <crtdbg.h>

// Change this number to the line number the Output window shows you
// to follow a memory leak. Put -1 to disable.
#define MEMORY_LEAK_LINE -1

int main()
{
	//Don't forget to include memory leak detection code ( supplied in lecture code as well but added here for convenience)
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	_CrtSetBreakAlloc(MEMORY_LEAK_LINE);

	//Int List
	DList <int> myIntList;

	//Testing provided push_back() method
	myIntList.push_back(3);
	myIntList.Push_Front(2);
	myIntList.push_back(4);
	myIntList.Push_Front(1);

	//Char Linked List
	DList <char> myCharList;

	//Testing provided push_back() method
	myCharList.push_back('P');
	myCharList.Push_Front('O');
	myCharList.push_back('E');
	myCharList.Push_Front('H');

	//Testing my bonus method: Print_Forward() method with both lists
	std::cout << "Printing Int List Backward: \t\t\t\t\t\t";
	myIntList.Print_Backward();
	std::cout << "Printing Char List Backward: \t\t\t\t\t\t";
	myCharList.Print_Backward();
	std::cout << std::endl;

	//Testing my bonus method: Print_Forward() method with both lists
	std::cout << "Printing Int List Forward: \t\t\t\t\t\t";
	myIntList.Print_Forward();
	std::cout << "Printing Char List Forward: \t\t\t\t\t\t";
	myCharList.Print_Forward();
	std::cout << std::endl;

	//Testing Clear() method.
	std::cout << "Clearing Int List and printing it Forward: ";
	myIntList.Clear();
	myIntList.Print_Forward();
	std::cout << "Clearing Char List and printing it Backward: ";
	myCharList.Clear();
	myCharList.Print_Backward();
	std::cout << std::endl;

	//Testing Push_Front() with both lists
	myIntList.push_back(1);
	myIntList.push_back(2);
	myIntList.push_back(3);
	myIntList.Push_Front(4);

	//Testing provided push_back() method
	myCharList.push_back('I');
	myCharList.push_back('P');
	myCharList.push_back('E');
	myCharList.Push_Front('L');		
	myCharList.Push_Front('E');
	myCharList.Push_Front('F');

	//Testing my bonus method: Print_Forward() method with both lists
	std::cout << "Printing Int List Backward: \t\t\t\t\t\t";
	myIntList.Print_Backward();
	std::cout << "Printing Char List Backward: \t\t\t\t\t\t";
	myCharList.Print_Backward();
	std::cout << std::endl;

	//Testing my bonus method: Print_Forward() method with both lists
	std::cout << "Printing Int List Forward: \t\t\t\t\t\t";
	myIntList.Print_Forward();
	std::cout << "Printing Char List Forward: \t\t\t\t\t\t";
	myCharList.Print_Forward();
	std::cout << std::endl;
	
	std::cout << "Added to Chars 'C' and 'D' to the list and printed forward: \t\t";
	myCharList.push_back('C');
	myCharList.push_back('D');
	myCharList.Print_Forward();
	std::cout << std::endl;

	std::cout << "Erasing Chars at indexes [1,2,3,4,5 and 6] to create my initials: \t";
	myCharList.Erase(6);
	myCharList.Erase(5);
	myCharList.Erase(4);
	myCharList.Erase(3);
	myCharList.Erase(2);
	myCharList.Erase(1);
	myCharList.Print_Forward();
	std::cout << "Erasing Ints at indexes [1 and 2] and printing backwards: \t\t";
	myIntList.Erase(2);
	myIntList.Erase(1);
	myIntList.Print_Backward();
	std::cout << std::endl;

	//Float DList
	DList <float> myFloatList;
	float randomFloat0 = 6 + (float)(rand()) / (float)(rand());
	float randomFloat1 = 7 + (float)(rand()) / (float)(rand());
	float randomFloat2 = 10 + (float)(rand()) / (float)(rand());
	
	std::cout << "Printing Float List Backward: \t\t\t\t\t\t";
	myFloatList.push_back(randomFloat1);
	myFloatList.Push_Front(randomFloat0);
	myFloatList.push_back(randomFloat2);
	myFloatList.Print_Backward();

	std::cout << "Printing Float List Forward : \t\t\t\t\t\t";
	myFloatList.Print_Forward();
	std::cout << std::endl;

	std::cout << "Erasing Float at index [1] and printing backwards: \t\t\t";
	myFloatList.Erase(1);
	myFloatList.Print_Backward();

	std::cout << "Clearing Float List and printing it Forward: ";
	myFloatList.Clear();
	myFloatList.Print_Forward();
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
