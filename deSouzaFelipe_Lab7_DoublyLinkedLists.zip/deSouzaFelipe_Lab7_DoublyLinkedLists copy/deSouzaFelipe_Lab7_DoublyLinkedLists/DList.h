#pragma once

#include <iostream>
#define TH template<typename Type>						

template<typename Type = int>
class DList
{
private:

	struct node
	{
		node* next, *prev;
		Type data;

		node(Type& _data, node* _prev) : data(_data), prev(_prev), next(nullptr) {}
	};

	int count;
	node* first, *last;

public:
	DList() { first = last = nullptr; count = 0; }
	~DList();

	int GetCount() { return count; }
	
	//Methods Declarations
	void push_back(Type _data);
	void Clear();
	void Push_Front(Type _data);
	void Erase(int _index);
	void Print_Forward() const;
	void Print_Backward() const;


	Type& operator[](int _index);
	const Type& operator[](int _index) const;

};


TH
//The purpose of the push_back function is to add a new node to the end of the list.
//It will act as an opposite of push_front
void DList<Type>::push_back(Type _data)
{
	node* n = new node(_data, last);

	if (last)
		last->next = n;
	else
		first = n;

	last = n;

	++count;
}

//The purpose of the clear function is to reset the list.  Zero size, no nodes, everything back to the default
template<typename Type>
void DList<Type>::Clear()
{
	while(first != nullptr) 
	{
		node* temp = first;
		first = first->next;
		delete temp;
	}
	last = nullptr;
	count = 0;
}

//The purpose of the push_front function is to add a new node to the beginning of the list.
//It will act as an opposite of push_back
template<typename Type>
void DList<Type>::Push_Front(Type _data)
{
	node* n = new node(_data, nullptr);

	if (first == nullptr) {
		first = last = n;
	}
	else {
		n->next = first;
		first->prev = n;
		first = n;
	}
	++count;
}

//The purpose of the Erase function is to traverse to a node based off a passed-in index, and then delete that node.  
//Erase will also need to make sure that it doesn�t impact the list around it. 
template<typename Type>
void DList<Type>::Erase(int _index)
{
	//checks if the list is empty and informs the user of it
	if (count == 0)
	{
		std::cout << "List is EMPTY!" << std::endl;
	}
	//Checks if index is out of bounds and informs the user of it
	if (_index < 0 || _index >= count)
	{
		std::cerr << " Index Out of Bounds!" << std::endl;
	}
	//Special Case 1: If list contains only one node ( == 1 )
	if (count == 1)
	{
		delete first;
		first = nullptr;
		last = nullptr;
		count = 0;	
	}
	
	//Special Case 2 : If deleting the first node ( == 0 )
	else if (_index == 0)
	{
		node* temp = first;
		first = first->next;
		first->prev = nullptr;
		delete temp;
		--count;					//Decrements the count of elements in the list
	}
	
	//Special Case 3: If deleting the last node ( == -1 )
	else if (_index == count -1)
	{
		node* temp = last;
		last = last->prev;
		last->next = nullptr;
		delete temp;
		--count;					//Decrements the count of elements in the list
	}

	//Default/Generic Case: Deleting if node is in/from middle of the list.
	node* current = first;
	for (int i = 0; i < _index; ++i)
	{
		current = current->next;
	}
	//Re-adjusting the pointers of existing(neighboring) nodes to bypass the node that needs to be deleted.
	current->prev->next = current->next;
	current->next->prev = current->prev;

	//Deletes the node at the specified index
	delete current;
	--count;						//Decrements the count of elements in the list
}

//traverse the list forward and prints out the data
template<typename Type>
void DList<Type>::Print_Forward() const
{
	node* temp = first;
	while (temp != nullptr)
	{
		std::cout << temp->data << " ";
		temp = temp->next;
	}
	std::cout << std::endl;
}

//traverses the list backwards and prints out the data
template<typename Type>
void DList<Type>::Print_Backward() const
{
	node* temp = last;
	while (temp != nullptr)
	{
		std::cout << temp->data << " ";
		temp = temp->prev;
	}
	std::cout << std::endl;
}

//Destructor used to clean things up (dynamic memory allocation, values, pointers, etc)
template<typename Type>
DList<Type>::~DList()
{
	Clear();
}

template<typename Type>
Type& DList<Type>::operator[](int _index)
{
	node* temp = first;

	int i = 0;
	for (; i < _index; ++i)
		temp = temp->next;

	return temp->data;
}

template<typename Type>
const Type& DList<Type>::operator[](int _index) const
{
	node* temp = first;

	int i = 0;
	for (; i < _index; ++i)
		temp = temp->next;

	return temp->data;
}