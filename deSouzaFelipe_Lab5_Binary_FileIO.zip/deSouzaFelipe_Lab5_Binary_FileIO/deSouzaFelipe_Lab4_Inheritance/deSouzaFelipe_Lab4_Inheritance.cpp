// deSouzaFelipe_Lab4_Inheritance.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Final Draft 4/21/24

#include <iostream>
#include <fstream>
#include <crtdbg.h>
#include "CheckingAccount.h"
#include "SavingsAccount.h"
#include "CreditAccount.h"
#include "Header.h"

//Globally in your main cpp file
#define MEMORY_LEAK_LINE -1

char bankName[] = "FSO Infla Bank";

/// <summary>
/// Function to write account balances to a binary file
/// </summary>
/// <param name="checkingAccount">Pointer of Checking Account</param>
/// <param name="savingsAccount">Pointer of Savings Account</param>
/// <param name="creditAccount">Pointer of Credit Account</param>
void writeBinaryToFile(BaseAccount* checkingAccount, BaseAccount* savingsAccount, BaseAccount* creditAccount)
{
    std::ofstream outFile;
    outFile.open("account_balance.bin", std::ios_base::binary | std::ios_base::trunc);

    if (outFile.is_open())
    {
        float checkingBalance = checkingAccount->GetBalance();
        float savingsBalance = savingsAccount->GetBalance();
        float creditBalance = creditAccount->GetBalance();

        checkingAccount->SetBalance(checkingBalance);
        savingsAccount->SetBalance(savingsBalance);
        creditAccount->SetBalance(creditBalance);

        outFile.write(reinterpret_cast<char*>(&checkingBalance), sizeof(checkingBalance));
        outFile.write(reinterpret_cast<char*>(&savingsBalance), sizeof(savingsBalance));
        outFile.write(reinterpret_cast<char*>(&creditBalance), sizeof(creditBalance));

        outFile.close();
    }
    else {
        std::cerr << "Unable to open file for writing at this time!" << std::endl;
    }
}


/// <summary>
/// Function to read account balances from a binary file
/// </summary>
/// <param name="checkingAccount">Pointer of Checking Account</param>
/// <param name="savingsAccount">Pointer of Savings Account</param>
/// <param name="creditAccount">Pointer of Credit Account</param>
void readBinaryFromFile(BaseAccount* checkingAccount, BaseAccount* savingsAccount, BaseAccount* creditAccount)
{
    std::ifstream inFile;
    inFile.open("account_balance.bin", std::ios_base::binary);

    if (inFile.is_open())
    {
        float checkingBalance = 0;
        float savingsBalance = 0;
        float creditBalance = 0;

        inFile.read(reinterpret_cast<char*>(&checkingBalance), sizeof(checkingBalance));
        inFile.read(reinterpret_cast<char*>(&savingsBalance), sizeof(savingsBalance));
        inFile.read(reinterpret_cast<char*>(&creditBalance), sizeof(creditBalance));


        checkingAccount->Deposit(checkingBalance);
        savingsAccount->Deposit(savingsBalance);
        creditAccount->Deposit(creditBalance);

        inFile.close();
    }
    else {
        //Initialize their balance amounts to whatever you want.
        checkingAccount->Deposit(1000);
        savingsAccount->Deposit(500);
        creditAccount->Deposit(200);
        std::cerr << "File not found! Initial amounts will be utilized!" << std::endl;
    }
}


//Create a function for withdraw and one for deposit that will take in a BaseAccount*. 
//Then pass the selected account pointer to this function.
void makeDeposit(BaseAccount* account)
{
    float amount = Helper::GetValidatedInt("What is the amount you would like to deposit: ");
    account->Deposit(amount);
    Helper::ClearConsole();
    Helper::PrintBannerMessage(bankName);
    std::cout << "$" << amount << ".00 were successfully deposited into your account! \n" << std::endl;
    std::cout << "Current Balance: $" << account->GetBalance() << ".00\n" << std::endl;
    Helper::PrintLineSeparator();
}

void makeWithdrawl(BaseAccount* account)
{
    float amount = Helper::GetValidatedInt("What is the amount you would like to withdrawal: ");
    account->Withdraw(amount);
}

int main()
{
    //Don't forget to include memory leak detection code ( supplied in lecture code as well but added here for convenience)
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
    _CrtSetBreakAlloc(MEMORY_LEAK_LINE);

    //Main will create an instance of each derived class; CheckingAccount*, SavingsAccount*, and CreditAccount* .
    //These instances should be initialized with new making the heap variables you will need to clean up.
    BaseAccount* checkingAccount = new CheckingAccount();
    BaseAccount* savingsAccount = new SavingsAccount();
    BaseAccount* creditAccount = new CreditAccount();

    readBinaryFromFile(checkingAccount, savingsAccount, creditAccount);

    Helper::PrintBannerMessage(bankName);

    //Then add a menu system that will allow for deposits and withdrawals to be made to the various accounts.
    //Make sure to let your menu run in a loop.
    bool running = true;
    while (running)
    {
        const char* menuOptions[4] = { "Checking Account", "Savings Account", "Credit Account", "Quit" };
        std::cout << "Please select an account to transact on:\n" << std::endl;
        int selectedOption = Helper::PrintMenuAndGetSelection(menuOptions, 4);

        const char* transactionMenuOptions[3] = { "Make a Deposit", "Make a Withdrawal", "Quit" };
        int selection;

        switch (selectedOption)
        {
        case 1:
        {   Helper::ClearConsole();
            Helper::PrintBannerMessage(bankName);
            std::cout << "Checking Account Balance: \t" << "$" << checkingAccount->GetBalance() << ".00 \n" << std::endl;
            selection = Helper::PrintMenuAndGetSelection(transactionMenuOptions, 3);
            
            if (selection == 1)
            {
                Helper::ClearConsole();
                Helper::PrintBannerMessage(bankName);
                makeDeposit(checkingAccount);
            }
            else if(selection == 2)
            {
                Helper::ClearConsole();
                Helper::PrintBannerMessage(bankName);
                makeWithdrawl(checkingAccount);
            }
            else 
            {
                Helper::ClearConsole();
                Helper::PrintBannerMessage(bankName);
                break;
            }
            break;
        }
        case 2:
        {
            Helper::ClearConsole();
            Helper::PrintBannerMessage(bankName);
            std::cout << "Savings Account Balance: \t" << "$" << savingsAccount->GetBalance() << ".00 \n" << std::endl;
            selection = Helper::PrintMenuAndGetSelection(transactionMenuOptions, 3);

            if (selection == 1)
            {
                Helper::ClearConsole();
                Helper::PrintBannerMessage(bankName);
                makeDeposit(savingsAccount);
            }
            else if (selection == 2)
            {
                Helper::ClearConsole();
                Helper::PrintBannerMessage(bankName);
                makeWithdrawl(savingsAccount);
            }
            else
            {
                Helper::ClearConsole();
                Helper::PrintBannerMessage(bankName);
                break;
            }
            break;
        }
        case 3:
        {
            Helper::ClearConsole();
            Helper::PrintBannerMessage(bankName);
            std::cout << "Credit Account Balance: \t" << "$" << creditAccount->GetBalance() << ".00 \n" << std::endl;
            selection = Helper::PrintMenuAndGetSelection(transactionMenuOptions, 3);

            if (selection == 1)
            {
                Helper::ClearConsole();
                Helper::PrintBannerMessage(bankName);
                makeDeposit(creditAccount);
            }
            else if (selection == 2)
            {
                Helper::ClearConsole();
                Helper::PrintBannerMessage(bankName);
                makeWithdrawl(creditAccount);
            }
            else
            {
                Helper::ClearConsole();
                Helper::PrintBannerMessage(bankName);
                break;
            }
            break;
        }
        case 4:
        {
            Helper::ClearConsole();
            Helper::PrintBannerMessage(bankName);
            running = false;
            std::cout << "Thank you for using FSO Infla Bank! \n\nWe hope you have a wonderful day!" << std::endl;
            break;
        }
        default:
            std::cerr << "Invalid selection! \nPlease try again..." << std::endl;
            break;
        }
    }

    writeBinaryToFile(checkingAccount, savingsAccount, creditAccount);

    //Don't forget to clean up memory.
    delete checkingAccount;
    delete savingsAccount;
    delete creditAccount;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
