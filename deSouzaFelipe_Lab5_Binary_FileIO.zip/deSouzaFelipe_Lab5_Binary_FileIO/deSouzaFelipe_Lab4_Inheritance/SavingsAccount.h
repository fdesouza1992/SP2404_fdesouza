#pragma once
#include "BaseAccount.h"

class SavingsAccount :  public BaseAccount
{
public:
	//It has no additional data members and must override the Withdraw function
	void Withdraw(float amount) override;
protected:

private:

};

