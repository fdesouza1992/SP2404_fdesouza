#pragma once
#include <iostream>
#include "Header.h"

//Create a BaseAccount Class
class BaseAccount
{
protected:
	//Give the class a protected float data member for the account balance and a protected int for the number of withdrawls
	float accountBalance;													//Field Members
	int numberOfWithdrawls;													//Field Members

public:
	//Initialize these both to 0 in either the class member declaration or in the default constructor
	BaseAccount() : accountBalance(0), numberOfWithdrawls(0) {}				//Base Constructor

	//Add the following public methods:
	virtual void Withdraw(float amount);									//Method
	virtual void Deposit(float amount);										//Method
	
	float GetBalance() const;												//Getter
	void SetBalance(float newBalance);										//Setter

private:

};

