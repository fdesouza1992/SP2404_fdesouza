#include "CheckingAccount.h"

//Must override the Withdraw function to enforce these rules:
void CheckingAccount::Withdraw(float amount)
{
	//Checking account charges a $5 fee if more than 10 withdrawals are made
	if (numberOfWithdrawls >= 10)
	{
		accountBalance -= (amount + 5);
		//When this fee is applied there should be a message informing the user this happened.
		std::cout << "\n$" << amount << ".00 were successfully withdrawn from your checking account!" << std::endl;
		std::cout << "Please Note: A $5.00 fee has been applied to your account for exceeding the withdrawl limit." << std::endl;
		std::cout << "\nCurrent Balance: $" << accountBalance << ".00\n" << std::endl;
		Helper::PrintLineSeparator();
	}
	else
	{
		//Withdrawls the requested amount from exisiting balance.
		accountBalance -= amount;
		std::cout << "\n$" << amount << ".00 were successfully withdrawn from your checking account!" << std::endl;
		std::cout << "\nCurrent Balance: $" << accountBalance << ".00\n" << std::endl;
		Helper::PrintLineSeparator();
		}
	numberOfWithdrawls++;
}
