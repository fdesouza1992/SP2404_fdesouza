﻿#include "Helper.h"

/// <summary>
/// This function should first display the provided message to the screen then use cin to get an int from the user.
///  Error check and validate to ensure a legal integer was entered. 
///  If not, clear the cin buffer using clear() and ignore() and try again 
///  (Note: the buffer still needs to be cleared even if this step was successful).
/// </summary>
/// <param name="strMessage">The provided message to be output for the user</param>
/// <param name="nMinimumRange">Minimum Number for the Range</param>
/// <param name="nMaximumRange">Maximum Number for the Range</param>
/// <returns>If the user input was within the range, return the integer. 
/// If not, get input again.</returns>
int Helper::GetValidatedInt(const char* strMessage, int nMinimumRange, int nMaximumRange)
{
    char userInput[10];
    int nUserInput;

    bool validation = true;

    do
    {
        std::cout << strMessage << std::endl;
        std::cin >> nUserInput;
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cerr << "Invalid entry! Please try again to continue ... " << std::endl;
        }
        else {
            //The range check should be ignored if BOTH the minimum and maximum parameters are 0, so any valid integer is acceptable.
            if ((nUserInput >= nMinimumRange || nMinimumRange == 0) && (nUserInput <= nMaximumRange || nMaximumRange == 0)) {
                return nUserInput;
            }
            else {
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                std::cerr << "Invalid entry! Please try again to continue ... " << std::endl;
            }
        }
    } while (validation);
}

/// <summary>
/// Helper Function to return a Random Number within a range.
/// </summary>
/// <param name="nMinimum">Minimum Number for the Range</param>
/// <param name="nMaximum">Maximum Number for the Range</param>
/// <returns>Random Int Number</returns>
int Helper::GetRandomIntNumber(int nMinimum, int nMaximum)
{
    srand(static_cast<unsigned int>(time(0)));
    return rand() % (nMaximum - nMinimum + 1) + nMinimum;
}

/// <summary>
/// Helper Function to clear and ignore the cin input buffer
/// </summary>
void Helper::ClearCinBuffer()
{
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

/// <summary>
/// Helper Function that prints a menu (array of strings) and return the user�s selection
/// </summary>
/// <param name="menuOptions">Different Options that will be displayed</param>
/// <param name="numberOptions">Number of options available</param>
/// <returns></returns>
int Helper::PrintMenuAndGetSelection(const char* menuOptions[], int numberOptions)
{
    for (int i = 0; i < numberOptions; i++)
    {
        std::cout << i + 1 << ". " << menuOptions[i] << std::endl;
    }
    return GetValidatedInt("\nSelect an Option: ", 1, numberOptions);
}

/// <summary>
/// Helper Function to print the binary representation of an unsigned integer.
/// </summary>
/// <param name="bitField">Binary Bits Representation</param>
void Helper::PrintBits(unsigned int bitField)
{
    for (int i = 31; i >= 0; i--) {     //Loops through each bit from the mosto the least significant bit (0)
        if (bitField & (1 << i)) {      //If the bit is set, print '1'
            std::cout << "1";
        }
        else {                          //if the bit is not set, print '0'
            std::cout << "0";
        }
        if (i % 4 == 0) {               //Adds a space every 4 bits for better readability
            std::cout << " ";
        }
    }
}

/// <summary>
/// Helper function that prints out a line of *** to be used as separator
/// </summary>
void Helper::PrintLineSeparator()
{
    std::cout << "*************************************************************\n" << std::endl;
}

/// <summary>
 /// Helper Function that prints a provided integer in binary, hex, or oct
 /// </summary>
 /// <param name="numToBeConverted">Int to be converted</param>
void Helper::PrintIntegerInFormats(int numToBeConverted)
{
    std::cout << "Decimal: \t" << numToBeConverted << std::endl;
    unsigned int bits = static_cast<unsigned int> (numToBeConverted);
    std::cout << "Binary: \t";
    PrintBits(bits);
    std::cout << std::endl;
    char hex_string[20];
    sprintf_s(hex_string, "%X", numToBeConverted);
    std::cout << "Hexadecimal: \t" << hex_string << std::endl;
    std::cout << "Octal: \t\t0" << std::oct << numToBeConverted << std::endl;
}

/// <summary>
/// Helper Function that displays "Press the Enter Key to continue" and wait for the enter to continue.
/// </summary>
void Helper::PrintPressEnterKey()
{
    std::cout << "Press the Enter Key to continue ..." << std::endl;
    std::cin.get();                     // Pause the console before moving on.
}

/// <summary>
/// Helper Function to Clear console and returns the cursor
/// </summary>
void Helper::ClearConsole()
{
    system("cls");
}

/// <summary>
/// Helper Function that shows a given message inside a banner box component
/// </summary>
/// <param name="message"></param>
void Helper::PrintBannerMessage(char message[])
{
    ClearConsole();
    PrintLineSeparator();
    std::cout << " " << message << "\n" << std::endl;
    PrintLineSeparator();
}
/// <summary>
/// Function to generate random float between min and max 
/// </summary>
/// <param name="min">minimum</param>
/// <param name="max">maximum</param>
/// <returns>a random float between range given</returns>
float Helper::GetRandomFloat(float min, float max)
{
    float randomFloat = min + static_cast<float>(rand()) / (static_cast<float> (RAND_MAX / (max - min)));
    return randomFloat;
}
