#pragma once
#include <iostream>

class Base
{
private:
//Add a private char* member to the class for the name and initialize it to nullptr.
	char* mName = nullptr;

public:
	Base();										//default constructor

//Finally, fully implement the Rule of 3 for the class because it has a dynamic memory member.
	Base(const Base& _copy);					//copy constructor
	Base& operator=(const Base& _copy);			//assignment operator
	virtual ~Base();							//destructor

//Implement a public SetName method (it must do a deep copy of the memory since the name is a dynamic pointer). 
//You may use the CopyString method from lecture.
	void SetName(const char* newName);

//Also add a public GetName() method that will return the name.
	char* GetName();

//Declare a public DisplayRecord method that is pure virtual (meaning it will have no definition) :
	virtual void DisplayRecord() = 0;

protected:

};

