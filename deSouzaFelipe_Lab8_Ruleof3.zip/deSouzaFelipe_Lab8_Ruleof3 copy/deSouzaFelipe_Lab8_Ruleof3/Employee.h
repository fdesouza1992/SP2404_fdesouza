#pragma once
#include "Base.h"

//Create an Employee class that publicly derives from Base. 
class Employee :   public Base
{
private:
//Give it a private int member for the salary
	int mSalary;

public:
//And implement a public SetSalary method
	void SetSalary(int newSalary);

//Then override and implement the DisplayRecord method 
//so that it prints the name using GetName() and the salary to the screen.
	void DisplayRecord() override;

protected:
};

