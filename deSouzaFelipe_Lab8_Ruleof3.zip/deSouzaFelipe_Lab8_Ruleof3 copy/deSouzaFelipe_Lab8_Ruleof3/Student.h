#pragma once
#include "Base.h"
//Create an Student class that publicly derives from Base. 
class Student :   public Base
{
private:
//Give it a float member for the GPA.
	float mGPA;

public:
//And implement a public SetGPA method
	void SetGPA(float newGPA);

//Then override and implement the DisplayRecord method 
//so that it prints the name using GetName() and the salary to the screen.
	void DisplayRecord() override;
};

