#include "Employee.h"

//Setters
void Employee::SetSalary(int newSalary)
{
	mSalary = newSalary;
}

//Then override and implement the DisplayRecord method so that it prints the name using GetName() and the salary to the screen.
void Employee::DisplayRecord()
{
	std::cout << "Name: " << GetName() << "\t |  Salary:\t" << mSalary << std::endl;
}
