#include "Student.h"

void Student::SetGPA(float newGPA)
{
	mGPA = newGPA;
}

void Student::DisplayRecord()
{
	std::cout << "Name: " << GetName() << "\t |  GPA:\t" << mGPA << std::endl;
}
