#pragma once
#include <iostream>
#include <climits>

namespace Helper
{
    int GetValidatedInt(const char* strMessage, int nMinimumRange = 0, int nMaximumRange = 0);
    int GetRandomIntNumber(int nMinimum, int nMaximum);
    void ClearCinBuffer();
    int PrintMenuAndGetSelection(const char* menuOptions[], int numberOptions);
    void PrintBits(unsigned int bitField);
    void PrintLineSeparator();
    void PrintIntegerInFormats(int numToBeConverted);
    void PrintPressEnterKey();
    void ClearConsole();
    void PrintBannerMessage(char message[]);
    float GetRandomFloat(float min, float max);
}