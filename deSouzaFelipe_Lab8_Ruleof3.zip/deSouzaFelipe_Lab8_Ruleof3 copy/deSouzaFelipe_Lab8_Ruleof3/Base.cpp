#include "Base.h"
#include <cstring>

Base::Base()									//default constructor
{
}

Base::Base(const Base& _copy)					//copy constructor
{
	*this = _copy;								//calls the copy constructor - it fixes the deep copy stuff
}

Base& Base::operator=(const Base& _copy)		//assignment operator
{
	if (this != &_copy)							//check to make sure not the same object
	{
		SetName(_copy.mName);					//deep copy for name ptr
	}
	return *this;
}

Base::~Base()									//destructor
{
	delete[] mName;
}

//Setters
void Base::SetName(const char* newName)
{
	if (mName != nullptr)
	{
		delete[] mName;
	}
	int length = strlen(newName) + 1;			//finds thr length of the array passed in
	mName = new char[length];					//new a char for model to point to
	strcpy_s(mName, length, newName);			//copy chars from _name to mName

}

//Getters
char* Base::GetName()
{
	return mName;
}

