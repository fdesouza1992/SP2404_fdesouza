// deSouzaFelipe_Lab8_Ruleof3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//Draft 5/3/24
#pragma once
#include <crtdbg.h>
#include <vector>
#include "Employee.h"
#include "Student.h"
#include "Helper.h"

// Change this number to the line number the Output window shows you
// to follow a memory leak. Put -1 to disable.
#define MEMORY_LEAK_LINE -1

//AddRecord(vector<Base*>& v) method
void AddRecord(std::vector<Base*>& records) 
{
	const char* menu[2] = { "Employee","Student"};
	std::cout << "What would you like to add: " << std::endl;				// Ask user for type of record (Employee or Student)
	int userChoice = Helper::PrintMenuAndGetSelection(menu, 2);
	
	Base* newRecord = nullptr;
	int salary;
	float gpa;

	switch (userChoice)
	{
	case 1:
	{
		std::cout << std::endl;
		Helper::PrintLineSeparator();
		newRecord = new Employee();					//Dynamically create new object based on user input
		char name[100];
		std::cout << "Enter Name: ";
		Helper::ClearCinBuffer();
		std::cin.getline(name, 100);
		newRecord->SetName(name);					//Set name and other attributes of the record
		std::cout << "Enter Salary: ";
		std::cin >> salary;
		static_cast<Employee*>(newRecord)->SetSalary(salary);	//Set name and other attributes of the record
		std::cout << "\nEmployee " << name << " with a salary of $" << salary << " has been successfully added!" << std::endl;
		std::cout << std::endl;
		Helper::PrintLineSeparator();
		break;
	}
	case 2:
	{
		std::cout << std::endl;
		Helper::PrintLineSeparator();
		newRecord = new Student();					//Dynamically create new object based on user input
		char name[100];
		std::cout << "Enter name: ";
		Helper::ClearCinBuffer();
		std::cin.getline(name, 100);
		newRecord->SetName(name);					//Set name and other attributes of the record
		std::cout << "Enter GPA: ";
		std::cin >> gpa;
		static_cast<Student*>(newRecord)->SetGPA(gpa);
		std::cout << "\nStudent " << name << " with a GPA of " << gpa << " has been successfully added!" << std::endl;
		std::cout << std::endl;
		Helper::PrintLineSeparator();
		break;
	}
	default:
		std::cerr << "Invalid choice.\n Please try again ..." << std::endl;
		break;
	}
	
	records.push_back(newRecord);					// Add the record to the vector
}

//DisplayRecord(vector<Base*>& v)
void DisplayRecord(std::vector<Base*>& records)
{
	std::cout << "Displaying All Records on File: " << std::endl;
	Helper::PrintLineSeparator();
	//loop through the vector of records and call each pointer�s DisplayRecord() method.
	for (Base* record : records)
	{
		record->DisplayRecord();
	}
	std::cout << std::endl;
	Helper::PrintLineSeparator();
}

//DuplicateRecord(vector<Base*>& v)
void DuplicateRecord(std::vector<Base*>& records)
{

	std::cout << "Duplicating a Record (Using Index): \n" << std::endl;
	Helper::PrintLineSeparator();
	int index;
	std::cout << "Enter index of record to duplicate: ";
	std::cin >> index;									//Ask user for index of record to duplicate

	if (index < 0 || index >= records.size()) 
	{
		std::cerr << "Invalid index.\n Please try again! ..." << std::endl;
	}

	Base* recordToDuplicate = records[index];

	if (Employee* employeeRecord = dynamic_cast<Employee*>(recordToDuplicate))			//Check if record is Student or Employee using dynamic_cast
	{
		Employee* newRecord = new Employee(*employeeRecord);							//Create a new record using copy constructor
		records.push_back(newRecord);													//Add the new record to the vector
	}
	else if (Student* studentRecord = dynamic_cast<Student*>(recordToDuplicate))		//Check if record is Student or Employee using dynamic_cast
	{
		Student* newRecord = new Student(*studentRecord);								//Create a new record using copy constructor
		records.push_back(newRecord);													//Add the new record to the vector
	}
	std::cout << recordToDuplicate->GetName() << " at index [" << index << "] duplicated successfully" << std::endl;
	Helper::PrintLineSeparator();
}

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	_CrtSetBreakAlloc(MEMORY_LEAK_LINE);

//Declare a vector of Base pointers in main.
	std::vector<Base*> records;

//Then create a menu loop that will allow the user to add a record, display all records, duplicate a record, or exit the menu loop.
	const char* menu[4] = { "Add a record","Display all records", "Duplicate a record", "Exit" };
	bool running = true;
	while(running)
	{
		std::cout << "What would you like to do today?: " << std::endl;
		int userChoice = Helper::PrintMenuAndGetSelection(menu, 4);

		switch (userChoice)
		{
		case 1: 
		{
			Helper::ClearConsole();
			AddRecord(records);
			break;
		}
		case 2:
		{
			Helper::ClearConsole();
			DisplayRecord(records);
			break;
		}
		case 3:
		{
			Helper::ClearConsole();
			DuplicateRecord(records);
			break;
		}
		case 4:
		{
			Helper::ClearConsole();
			for (Base* record : records) 
			{
				delete[] record;
			}
			std::cout << "Thank you for using this program!\nHave a blessed day! ..." << std::endl;
			running = false;
			break;
		}
		default:
			std::cerr << "Invalid choice.\nPlease try again! ..." << std::endl;
			break;
		}
	}
}

